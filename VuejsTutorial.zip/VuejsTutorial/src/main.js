// main.js

import Vue from 'vue';
import FormComponent from './components/FormComponent.vue';

new Vue({
  el: '#app',
  render: h => h(FormComponent)
});